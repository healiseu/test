(* Mathematica Init File *)

Get[ "DBAPI`Utils`"];
Get[ "DBAPI`OrientDB`"];
Get[ "DBAPI`FreebaseAPI`"];
Get[ "DBAPI`OrientR3S3`"];